import hashlib
import hmac
import json
import os
from urllib.parse import unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from database import db
from slots import do_spin
from config import BOT_TOKEN

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static Mini App files
STATIC_DIR = os.path.join(os.path.dirname(__file__), "../webapp/static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.on_event("startup")
async def startup():
    await db.init()


def verify_telegram_data(init_data: str) -> dict | None:
    """Verify that the request comes from Telegram"""
    try:
        parsed = {}
        for part in init_data.split("&"):
            k, v = part.split("=", 1)
            parsed[k] = unquote(v)

        received_hash = parsed.pop("hash", "")
        data_check_string = "\n".join(
            f"{k}={v}" for k, v in sorted(parsed.items())
        )
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        computed_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

        if hmac.compare_digest(computed_hash, received_hash):
            user_data = json.loads(parsed.get("user", "{}"))
            return user_data
        return None
    except Exception:
        return None


class SpinRequest(BaseModel):
    init_data: str
    bet: int


class UserRequest(BaseModel):
    init_data: str


@app.get("/")
async def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.post("/api/user")
async def get_user(req: UserRequest):
    user_data = verify_telegram_data(req.init_data)
    if not user_data:
        raise HTTPException(status_code=403, detail="Invalid Telegram data")

    user_id = user_data["id"]
    username = user_data.get("username", "")

    await db.create_user(user_id, username)
    user = await db.get_user(user_id)
    return {"balance": user["balance"], "games_played": user["games_played"]}


@app.post("/api/spin")
async def spin(req: SpinRequest):
    user_data = verify_telegram_data(req.init_data)
    if not user_data:
        raise HTTPException(status_code=403, detail="Invalid Telegram data")

    user_id = user_data["id"]
    user = await db.get_user(user_id)

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Validate bet
    MIN_BET, MAX_BET = 1, 100
    if req.bet < MIN_BET or req.bet > MAX_BET:
        raise HTTPException(status_code=400, detail=f"Bet must be between {MIN_BET} and {MAX_BET}")

    if user["balance"] < req.bet:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    # Do the spin
    result = do_spin(req.bet)
    await db.update_after_spin(user_id, req.bet, result["win"])

    # Get updated balance
    updated_user = await db.get_user(user_id)

    return {
        "reels": result["emojis"],
        "win": result["win"],
        "net": result["net"],
        "message": result["message"],
        "is_win": result["is_win"],
        "balance": updated_user["balance"],
    }
