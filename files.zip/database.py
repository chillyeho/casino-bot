import aiosqlite
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "casino.db")


class Database:
    def __init__(self):
        self.db_path = DB_PATH

    async def init(self):
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    balance INTEGER DEFAULT 50,
                    total_bet INTEGER DEFAULT 0,
                    total_won INTEGER DEFAULT 0,
                    games_played INTEGER DEFAULT 0
                )
            """)
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount INTEGER,
                    type TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            await conn.commit()

    async def create_user(self, user_id: int, username: str):
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                "INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)",
                (user_id, username)
            )
            await conn.commit()

    async def get_user(self, user_id: int):
        async with aiosqlite.connect(self.db_path) as conn:
            conn.row_factory = aiosqlite.Row
            async with conn.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                return dict(row) if row else None

    async def add_balance(self, user_id: int, amount: int):
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (amount, user_id)
            )
            await conn.execute(
                "INSERT INTO transactions (user_id, amount, type) VALUES (?, ?, 'deposit')",
                (user_id, amount)
            )
            await conn.commit()

    async def update_after_spin(self, user_id: int, bet: int, won: int):
        """Deduct bet, add winnings, update stats"""
        net = won - bet
        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute("""
                UPDATE users SET
                    balance = balance + ?,
                    total_bet = total_bet + ?,
                    total_won = total_won + ?,
                    games_played = games_played + 1
                WHERE user_id = ?
            """, (net, bet, won, user_id))
            await conn.execute(
                "INSERT INTO transactions (user_id, amount, type) VALUES (?, ?, 'spin')",
                (user_id, net)
            )
            await conn.commit()


db = Database()
