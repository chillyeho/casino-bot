import random
from typing import Tuple, List

# Symbols with weights — lower weight = rarer
# Format: (symbol, emoji, weight)
SYMBOLS = [
    ("seven",    "7️⃣",  2),   # Ultra rare — jackpot
    ("diamond",  "💎",  4),   # Very rare
    ("crown",    "👑",  6),   # Rare
    ("bell",     "🔔",  10),  # Uncommon
    ("cherry",   "🍒",  18),  # Common
    ("lemon",    "🍋",  25),  # Common
    ("grape",    "🍇",  35),  # Very common (filler)
]

SYMBOL_NAMES = [s[0] for s in SYMBOLS]
SYMBOL_EMOJIS = {s[0]: s[1] for s in SYMBOLS}
WEIGHTS = [s[2] for s in SYMBOLS]

# Payout multipliers for 3-of-a-kind (x bet)
PAYOUTS_3 = {
    "seven":   50,   # 50x — jackpot
    "diamond": 20,
    "crown":   10,
    "bell":    5,
    "cherry":  3,
    "lemon":   2,
    "grape":   1.5,
}

# Payout for 2-of-a-kind (only high symbols)
PAYOUTS_2 = {
    "seven":   5,
    "diamond": 3,
    "crown":   2,
}

# House edge control: occasionally force a near-miss or lose
# RTP target: ~65% (house keeps ~35%)
HOUSE_FORCE_LOSE_CHANCE = 0.42  # 42% of spins are forced losses


def spin_reels() -> List[str]:
    """Spin 3 reels with weighted random selection"""
    return [
        random.choices(SYMBOL_NAMES, weights=WEIGHTS, k=1)[0]
        for _ in range(3)
    ]


def calculate_win(reels: List[str], bet: int) -> Tuple[int, str]:
    """
    Returns (winnings, result_text)
    winnings = 0 means full loss
    """
    s1, s2, s3 = reels

    # 3 of a kind
    if s1 == s2 == s3:
        multiplier = PAYOUTS_3[s1]
        win = int(bet * multiplier)
        if s1 == "seven":
            return win, "🎊 ДЖЕКПОТ! ТРОЙНАЯ СЕМЁРКА!"
        return win, f"🎉 Три {SYMBOL_EMOJIS[s1]}! Выигрыш x{multiplier}!"

    # 2 of a kind (high symbols only)
    if s1 == s2 and s1 in PAYOUTS_2:
        multiplier = PAYOUTS_2[s1]
        win = int(bet * multiplier)
        return win, f"✨ Два {SYMBOL_EMOJIS[s1]}! Выигрыш x{multiplier}!"
    if s2 == s3 and s2 in PAYOUTS_2:
        multiplier = PAYOUTS_2[s2]
        win = int(bet * multiplier)
        return win, f"✨ Два {SYMBOL_EMOJIS[s2]}! Выигрыш x{multiplier}!"
    if s1 == s3 and s1 in PAYOUTS_2:
        multiplier = PAYOUTS_2[s1]
        win = int(bet * multiplier)
        return win, f"✨ Два {SYMBOL_EMOJIS[s1]}! Выигрыш x{multiplier}!"

    return 0, "😔 Не повезло..."


def do_spin(bet: int) -> dict:
    """
    Main spin function.
    Returns full result dict.
    """
    # Force loss sometimes to maintain house edge
    force_lose = random.random() < HOUSE_FORCE_LOSE_CHANCE

    if force_lose:
        # Generate a losing combo (all different, no pairs of rare symbols)
        while True:
            reels = spin_reels()
            win, _ = calculate_win(reels, bet)
            if win == 0:
                break
    else:
        reels = spin_reels()

    win, message = calculate_win(reels, bet)

    return {
        "reels": reels,
        "emojis": [SYMBOL_EMOJIS[r] for r in reels],
        "bet": bet,
        "win": win,
        "net": win - bet,
        "message": message,
        "is_win": win > 0,
    }
