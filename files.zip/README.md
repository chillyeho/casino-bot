# 🎰 Lucky Stars Casino Bot

Telegram-бот с Mini App для игры в слоты на Telegram Stars.

## Структура проекта

```
casino_bot/
├── bot/
│   ├── main.py       — Telegram бот (aiogram)
│   ├── api.py        — FastAPI сервер (API для Mini App)
│   ├── slots.py      — Логика слотов (RTP ~65%)
│   ├── database.py   — SQLite база данных
│   └── config.py     — Конфиг
├── webapp/
│   └── static/
│       └── index.html — Telegram Mini App (фронтенд)
├── requirements.txt
└── .env.example
```

---

## Установка

### 1. Создай бота в Telegram
1. Напиши [@BotFather](https://t.me/BotFather)
2. Команда `/newbot` → получи токен
3. Команда `/newapp` → прикрепи Mini App к боту (нужен HTTPS URL)

### 2. Настрой сервер (нужен VPS с HTTPS)
Для Mini App обязательно нужен HTTPS домен.  
Рекомендую: **Railway**, **Render**, или любой VPS + nginx + certbot.

### 3. Установи зависимости
```bash
cd casino_bot
pip install -r requirements.txt
```

### 4. Создай .env файл
```bash
cp .env.example .env
# Отредактируй .env — вставь свой BOT_TOKEN и URL сайта
```

### 5. Запуск

**Запусти API сервер** (в одном терминале):
```bash
cd bot
uvicorn api:app --host 0.0.0.0 --port 8000
```

**Запусти бота** (в другом терминале):
```bash
cd bot
python main.py
```

---

## Математика (RTP)

| Символ | 3 подряд | 2 подряд |
|--------|----------|----------|
| 7️⃣ | x50 | x5 |
| 💎 | x20 | x3 |
| 👑 | x10 | x2 |
| 🔔 | x5 | — |
| 🍒 | x3 | — |
| 🍋 | x2 | — |
| 🍇 | x1.5 | — |

- **Частота принудительных проигрышей**: 42%
- **Итоговый RTP**: ~65% (казино зарабатывает ~35% от всех ставок)

---

## Деплой на Railway (бесплатно)

1. Зарегистрируйся на [railway.app](https://railway.app)
2. Создай новый проект → Deploy from GitHub
3. Добавь переменные окружения (BOT_TOKEN, WEBAPP_URL)
4. Добавь `Procfile`:
```
web: uvicorn bot.api:app --host 0.0.0.0 --port $PORT
worker: python bot/main.py
```

---

## Добавить новые игры

В папке `bot/` можно создать `crash.py`, `mines.py` и т.д. по аналогии со `slots.py`, и добавить новые эндпоинты в `api.py`.
