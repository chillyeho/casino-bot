import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, LabeledPrice, PreCheckoutQuery, CallbackQuery
)
from aiogram.filters import CommandStart
from aiogram.fsm.storage.memory import MemoryStorage
from database import db
from config import BOT_TOKEN, WEBAPP_URL

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


@dp.message(CommandStart())
async def start(message: Message):
    await db.create_user(message.from_user.id, message.from_user.username or "")
    user = await db.get_user(message.from_user.id)

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🎰 Играть в слоты",
            web_app=WebAppInfo(url=f"{WEBAPP_URL}?user_id={message.from_user.id}")
        )],
        [InlineKeyboardButton(text="💰 Баланс", callback_data="balance")],
        [InlineKeyboardButton(text="⭐ Купить Stars", callback_data="buy_stars")],
    ])

    await message.answer(
        f"🎰 <b>Lucky Stars Casino</b>\n\n"
        f"Привет, <b>{message.from_user.first_name}</b>!\n"
        f"Твой баланс: <b>{user['balance']} ⭐</b>\n\n"
        f"Нажми кнопку и испытай удачу!",
        reply_markup=keyboard,
        parse_mode="HTML"
    )


@dp.callback_query(F.data == "balance")
async def balance(call: CallbackQuery):
    user = await db.get_user(call.from_user.id)
    await call.answer(f"Твой баланс: {user['balance']} ⭐", show_alert=True)


@dp.callback_query(F.data == "buy_stars")
async def buy_stars(call: CallbackQuery):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⭐ 100 Stars — 100 XTR", callback_data="pay_100")],
        [InlineKeyboardButton(text="⭐ 500 Stars — 450 XTR", callback_data="pay_500")],
        [InlineKeyboardButton(text="⭐ 1000 Stars — 800 XTR", callback_data="pay_1000")],
    ])
    await call.message.answer("Выбери пакет Stars для покупки:", reply_markup=keyboard)
    await call.answer()


@dp.callback_query(F.data.startswith("pay_"))
async def send_invoice(call: CallbackQuery):
    amounts = {"pay_100": (100, 100), "pay_500": (500, 450), "pay_1000": (1000, 800)}
    stars, price = amounts[call.data]

    await bot.send_invoice(
        chat_id=call.from_user.id,
        title=f"⭐ {stars} Stars",
        description=f"Пополнение баланса на {stars} игровых Stars",
        payload=f"stars_{stars}_{call.from_user.id}",
        currency="XTR",  # Telegram Stars currency
        prices=[LabeledPrice(label=f"{stars} Stars", amount=price)],
        provider_token="",  # empty for Telegram Stars
    )
    await call.answer()


@dp.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)


@dp.message(F.successful_payment)
async def successful_payment(message: Message):
    payload = message.successful_payment.invoice_payload
    parts = payload.split("_")
    stars = int(parts[1])
    user_id = int(parts[2])

    await db.add_balance(user_id, stars)
    user = await db.get_user(user_id)

    await message.answer(
        f"✅ Оплата прошла успешно!\n"
        f"Начислено: <b>{stars} ⭐</b>\n"
        f"Новый баланс: <b>{user['balance']} ⭐</b>",
        parse_mode="HTML"
    )


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
